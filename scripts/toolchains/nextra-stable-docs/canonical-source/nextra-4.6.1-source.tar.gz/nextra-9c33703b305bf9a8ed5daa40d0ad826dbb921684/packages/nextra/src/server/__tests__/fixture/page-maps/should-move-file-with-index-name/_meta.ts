export default {
  foo: '',
  index: ''
}
