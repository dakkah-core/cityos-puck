export default {
  index: ''
}
